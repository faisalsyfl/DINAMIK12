
-- --------------------------------------------------------

--
-- Table structure for table `tb_schteam`
--

DROP TABLE IF EXISTS `tb_schteam`;
CREATE TABLE `tb_schteam` (
  `schteam_id` int(11) NOT NULL,
  `schteam_name` varchar(255) NOT NULL,
  `schteam_coach_name` varchar(255) DEFAULT NULL,
  `schteam_coach_contact` varchar(20) DEFAULT NULL,
  `schteam_school_id` int(11) NOT NULL,
  `schteam_event_id` int(11) NOT NULL,
  `schteam_payment_id` int(11) NOT NULL,
  `schteam_account_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- RELATIONS FOR TABLE `tb_schteam`:
--   `schteam_school_id`
--       `tb_school` -> `school_id`
--   `schteam_payment_id`
--       `tb_payment` -> `payment_id`
--   `schteam_event_id`
--       `tb_event` -> `event_id`
--   `schteam_account_id`
--       `tb_account` -> `account_id`
--

--
-- Truncate table before insert `tb_schteam`
--

TRUNCATE TABLE `tb_schteam`;