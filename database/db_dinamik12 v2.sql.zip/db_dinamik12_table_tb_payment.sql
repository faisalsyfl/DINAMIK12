
-- --------------------------------------------------------

--
-- Table structure for table `tb_payment`
--

DROP TABLE IF EXISTS `tb_payment`;
CREATE TABLE `tb_payment` (
  `payment_id` int(11) NOT NULL,
  `payment_amount` double NOT NULL,
  `payment_document` varchar(255) NOT NULL,
  `payment_status` tinyint(1) NOT NULL,
  `payment_description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- RELATIONS FOR TABLE `tb_payment`:
--

--
-- Truncate table before insert `tb_payment`
--

TRUNCATE TABLE `tb_payment`;