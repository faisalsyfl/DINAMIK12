
-- --------------------------------------------------------

--
-- Table structure for table `tb_schparticipant`
--

DROP TABLE IF EXISTS `tb_schparticipant`;
CREATE TABLE `tb_schparticipant` (
  `schparticipant_id` int(11) NOT NULL,
  `schparticipant_name` varchar(255) NOT NULL,
  `schparticipant_nisn` varchar(20) NOT NULL,
  `schparticipant_birth` date NOT NULL,
  `schparticipant_gender` char(1) NOT NULL,
  `schparticipant_contact` varchar(20) NOT NULL,
  `schparticipant_address` text NOT NULL,
  `schparticipant_student_id` text NOT NULL,
  `schparticipant_schteam_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- RELATIONS FOR TABLE `tb_schparticipant`:
--   `schparticipant_schteam_id`
--       `tb_schteam` -> `schteam_id`
--

--
-- Truncate table before insert `tb_schparticipant`
--

TRUNCATE TABLE `tb_schparticipant`;