
-- --------------------------------------------------------

--
-- Table structure for table `tb_account`
--

DROP TABLE IF EXISTS `tb_account`;
CREATE TABLE `tb_account` (
  `account_id` int(11) NOT NULL,
  `account_email` varchar(255) NOT NULL,
  `account_username` varchar(16) NOT NULL,
  `account_password` varchar(255) NOT NULL,
  `account_log` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Last login',
  `account_category_id` varchar(10) NOT NULL,
  `account_token` varchar(255) NOT NULL COMMENT 'Cookies token',
  `account_image` text NOT NULL COMMENT 'Gambar kategori',
  `account_status` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- RELATIONS FOR TABLE `tb_account`:
--   `account_category_id`
--       `tb_category` -> `category_id`
--

--
-- Truncate table before insert `tb_account`
--

TRUNCATE TABLE `tb_account`;
--
-- Dumping data for table `tb_account`
--

INSERT INTO `tb_account` (`account_id`, `account_email`, `account_username`, `account_password`, `account_log`, `account_category_id`, `account_token`, `account_image`, `account_status`) VALUES
(0, 'dinamik.cs@upi.edu', 'admin', '21232f297a57a5a743894a0e4a801fc3', '2017-01-02 18:23:46', 'X-SUADM', '', '', 1),
(1, 'dinamik.cs@upi.edu', 'ketuplak', '21232f297a57a5a743894a0e4a801fc3', '2017-01-02 19:36:56', 'A-PLAK', '', '', 1),
(2, 'dinamik.cs@upi.edu', 'acara', '21232f297a57a5a743894a0e4a801fc3', '2017-01-02 19:37:22', 'B-ACARA', '', '', 1),
(3, 'dinamik.cs@upi.edu', 'bendahara', '21232f297a57a5a743894a0e4a801fc3', '2017-01-02 19:40:06', 'B-BDHR', '', '', 1),
(4, 'dinamik.cs@upi.edu', 'danusbazaar', '21232f297a57a5a743894a0e4a801fc3', '2017-01-02 19:40:06', 'B-DNSBZR', '', '', 1),
(5, 'dinamik.cs@upi.edu', 'dokumentasi', '21232f297a57a5a743894a0e4a801fc3', '2017-01-02 19:40:06', 'B-DOK', '', '', 1),
(6, 'dinamik.cs@upi.edu', 'publikasi', '21232f297a57a5a743894a0e4a801fc3', '2017-01-02 19:40:06', 'B-PUBLKS', '', '', 1),
(7, 'dinamik.cs@upi.edu', 'sponsor', '21232f297a57a5a743894a0e4a801fc3', '2017-01-02 19:50:03', 'B-SPONSOR', '', '', 1);
(8, 'dinamik.cs@upi.edu', 'cspc', '21232f297a57a5a743894a0e4a801fc3', '2017-01-02 19:44:00', 'C-CSPC', '', '', 1),
(9, 'dinamik.cs@upi.edu', 'donor', '21232f297a57a5a743894a0e4a801fc3', '2017-01-02 19:44:00', 'C-DONOR', '', '', 1),
(10, 'dinamik.cs@upi.edu', 'dstar', '21232f297a57a5a743894a0e4a801fc3', '2017-01-02 19:44:00', 'C-DSTAR', '', '', 1),
(11, 'dinamik.cs@upi.edu', 'felose', '21232f297a57a5a743894a0e4a801fc3', '2017-01-02 19:44:00', 'C-FELOSE', '', '', 1),
(12, 'dinamik.cs@upi.edu', 'komjar', '21232f297a57a5a743894a0e4a801fc3', '2017-01-02 19:44:00', 'C-KJ', '', '', 1),
(13, 'dinamik.cs@upi.edu', 'lca', '21232f297a57a5a743894a0e4a801fc3', '2017-01-02 19:44:00', 'C-LCA', '', '', 1),
(14, 'dinamik.cs@upi.edu', 'lcw', '21232f297a57a5a743894a0e4a801fc3', '2017-01-02 19:44:00', 'C-LCW', '', '', 1),
(15, 'dinamik.cs@upi.edu', 'ldg', '21232f297a57a5a743894a0e4a801fc3', '2017-01-02 19:44:00', 'C-LDG', '', '', 1),
(16, 'dinamik.cs@upi.edu', 'otik', '21232f297a57a5a743894a0e4a801fc3', '2017-01-02 19:44:00', 'C-OTIK', '', '', 1),
(17, 'dinamik.cs@upi.edu', 'pca', '21232f297a57a5a743894a0e4a801fc3', '2017-01-02 19:44:00', 'C-PCA', '', '', 1),
(18, 'dinamik.cs@upi.edu', 'rlf', '21232f297a57a5a743894a0e4a801fc3', '2017-01-02 19:44:00', 'C-RLF', '', '', 1),
(19, 'dinamik.cs@upi.edu', 'semnas', '21232f297a57a5a743894a0e4a801fc3', '2017-01-02 19:44:00', 'C-SEMNAS', '', '', 1),
(20, 'dinamik.cs@upi.edu', 'talkshow', '21232f297a57a5a743894a0e4a801fc3', '2017-01-02 19:44:00', 'C-TALKSHOW', '', '', 1),
(21, 'dinamik.cs@upi.edu', 'workshop', '21232f297a57a5a743894a0e4a801fc3', '2017-01-02 19:44:00', 'C-WORKSHOP', '', '', 1),
