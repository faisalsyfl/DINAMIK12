
-- --------------------------------------------------------

--
-- Table structure for table `tb_pubteam`
--

DROP TABLE IF EXISTS `tb_pubteam`;
CREATE TABLE `tb_pubteam` (
  `pubteam_id` int(11) NOT NULL,
  `pubteam_public_id` int(11) NOT NULL,
  `pubteam_event_id` int(11) NOT NULL,
  `pubteam_payment_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- RELATIONS FOR TABLE `tb_pubteam`:
--   `pubteam_public_id`
--       `tb_public` -> `public_id`
--   `pubteam_payment_id`
--       `tb_payment` -> `payment_id`
--   `pubteam_event_id`
--       `tb_event` -> `event_id`
--

--
-- Truncate table before insert `tb_pubteam`
--

TRUNCATE TABLE `tb_pubteam`;