
-- --------------------------------------------------------

--
-- Table structure for table `tb_event`
--

DROP TABLE IF EXISTS `tb_event`;
CREATE TABLE `tb_event` (
  `event_id` int(11) NOT NULL,
  `event_code` varchar(10) NOT NULL,
  `event_name` varchar(255) NOT NULL,
  `event_status` tinyint(1) NOT NULL COMMENT '1 = valid/bisa daftar, 0 = tutup, 9 = spesial',
  `event_capacity` int(5) NOT NULL,
  `event_description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- RELATIONS FOR TABLE `tb_event`:
--

--
-- Truncate table before insert `tb_event`
--

TRUNCATE TABLE `tb_event`;
--
-- Dumping data for table `tb_event`
--

INSERT INTO `tb_event` (`event_id`, `event_code`, `event_name`, `event_status`, `event_capacity`, `event_description`) VALUES
(1, 'LDG', 'Lomba Desain Grafis', 0, 50, 'Lomba Desain Grafis'),
(2, 'LCW', 'Lomba Cipta Web', 0, 50, ''),
(3, 'OTIK', 'Olimpiade Teknologi Informasi dan Komunikasi', 0, 50, ''),
(4, 'PCA', 'Personal Computer Assembling', 0, 50, ''),
(5, 'CSPC', 'Computer Science Programming Contest', 0, 50, ''),
(6, 'LCA', 'Lomba Cipta Animasi', 0, 50, ''),
(7, 'RLF', 'Robot Line Follower', 0, 50, ''),
(8, 'KJ', 'Kompetisi Jaringan', 0, 50, ''),
(9, 'TALKSHOW', 'Talkshow Inspiratif', 0, 50, ''),
(10, 'SEMNAS', 'Seminar Nasional', 0, 50, ''),
(11, 'FELOSE', 'Festival Teknologi dan Seni', 0, 50, ''),
(12, 'DONOR', 'Donor Darah', 0, 50, ''),
(13, 'WORKSHOP', 'Workshop Digitalisasi Guru', 0, 50, ''),
(14, 'DSTAR', 'Dinamik Star', 0, 50, '');
