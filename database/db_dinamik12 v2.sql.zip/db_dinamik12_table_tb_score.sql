
-- --------------------------------------------------------

--
-- Table structure for table `tb_score`
--

DROP TABLE IF EXISTS `tb_score`;
CREATE TABLE `tb_score` (
  `score_id` int(11) NOT NULL,
  `score_score` int(11) NOT NULL,
  `score_judge_id` int(11) NOT NULL,
  `score_event_id` int(11) NOT NULL,
  `score_schteam_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- RELATIONS FOR TABLE `tb_score`:
--   `score_judge_id`
--       `tb_judge` -> `judge_id`
--   `score_event_id`
--       `tb_event` -> `event_id`
--   `score_schteam_id`
--       `tb_schteam` -> `schteam_id`
--

--
-- Truncate table before insert `tb_score`
--

TRUNCATE TABLE `tb_score`;