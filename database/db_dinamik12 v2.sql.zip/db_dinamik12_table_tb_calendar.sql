
-- --------------------------------------------------------

--
-- Table structure for table `tb_calendar`
--

DROP TABLE IF EXISTS `tb_calendar`;
CREATE TABLE `tb_calendar` (
  `calendar_id` int(11) NOT NULL,
  `calendar_event_id` int(11) NOT NULL,
  `calendar_start_date` date NOT NULL,
  `calendar_end_date` date NOT NULL,
  `calendar_start_time` time NOT NULL,
  `calendar_end_time` time NOT NULL,
  `calendar_event_name` varchar(255) NOT NULL,
  `calendar_event_description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Tabel daftar acara buat kalender';

--
-- RELATIONS FOR TABLE `tb_calendar`:
--   `calendar_event_id`
--       `tb_event` -> `event_id`
--

--
-- Truncate table before insert `tb_calendar`
--

TRUNCATE TABLE `tb_calendar`;