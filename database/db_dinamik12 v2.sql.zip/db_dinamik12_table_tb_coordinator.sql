
-- --------------------------------------------------------

--
-- Table structure for table `tb_coordinator`
--

DROP TABLE IF EXISTS `tb_coordinator`;
CREATE TABLE `tb_coordinator` (
  `coordinator_id` int(11) NOT NULL,
  `coordinator_name` varchar(255) NOT NULL,
  `coordinator_contact` varchar(20) DEFAULT NULL,
  `coordinator_address` text,
  `coordinator_event_id` int(11) DEFAULT NULL,
  `coordinator_account_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- RELATIONS FOR TABLE `tb_coordinator`:
--   `coordinator_event_id`
--       `tb_event` -> `event_id`
--   `coordinator_account_id`
--       `tb_account` -> `account_id`
--

--
-- Truncate table before insert `tb_coordinator`
--

TRUNCATE TABLE `tb_coordinator`;
--
-- Dumping data for table `tb_coordinator`
--

INSERT INTO `tb_coordinator` (`coordinator_id`, `coordinator_name`, `coordinator_contact`, `coordinator_address`, `coordinator_event_id`, `coordinator_account_id`) VALUES
(0, 'Super Admin', NULL, NULL, NULL, 0),
(1, 'Ketua Pelaksana', NULL, NULL, NULL, 1),
(2, 'Koordinator Acara', NULL, NULL, NULL, 2),
(3, 'Bendahara', NULL, NULL, NULL, 3),
(4, 'Danus dan Bazaar', NULL, NULL, NULL, 4),
(5, 'Dokumentasi', NULL, NULL, NULL, 5),
(6, 'Publikasi', NULL, NULL, NULL, 6),
(7, 'Sponsor', NULL, NULL, NULL, 7);
(8, 'Koordinator CSPC', NULL, NULL, 5, 8),
(9, 'Koordinator Donor Darah', NULL, NULL, 12, 9),
(10, 'Koordinator Dinamik Star', NULL, NULL, 14, 10),
(11, 'Koordinator Festival Teknologi dan Seni', NULL, NULL, 11, 11),
(12, 'Koordinator Kompetisi Jaringan', NULL, NULL, 8, 12),
(13, 'Koordinator Lomba Cipta Animasi', NULL, NULL, 6, 13),
(14, 'Koordinator Lomba Cipta Web', NULL, NULL, 2, 14),
(15, 'Koordinator Lomba Desain Grafis', NULL, NULL, 1, 15),
(16, 'Koordinator Olimpiade Teknologi Informasi dan Komunikasi', NULL, NULL, 3, 16),
(17, 'Koordinator PC Assembling', NULL, NULL, 4, 17),
(18, 'Koordinator Robot Line Follower', NULL, NULL, 7, 18),
(19, 'Koordinator Seminar Nasional', NULL, NULL, 10, 19),
(20, 'Koordinator Talkshow', NULL, NULL, 9, 20),
(21, 'Koordinator Workshop', NULL, NULL, 13, 21),
