
-- --------------------------------------------------------

--
-- Table structure for table `tb_category`
--

DROP TABLE IF EXISTS `tb_category`;
CREATE TABLE `tb_category` (
  `category_id` varchar(10) NOT NULL,
  `category_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- RELATIONS FOR TABLE `tb_category`:
--

--
-- Truncate table before insert `tb_category`
--

TRUNCATE TABLE `tb_category`;
--
-- Dumping data for table `tb_category`
--

INSERT INTO `tb_category` (`category_id`, `category_name`) VALUES
('A-PLAK', 'Administrator - Ketua Pelaksana'),
('B-ACARA', 'Koordinator Acara'),
('B-BDHR', 'Bendahara'),
('B-DNSBZR', 'Danus & Bazaar'),
('B-DOK', 'Dokumentasi'),
('B-PUBLKS', 'Publikasi'),
('B-SPONSOR', 'Sponsor'),
('C-CSPC', 'Koordinator CSPC'),
('C-DONOR', 'Koordinator Donor Darah'),
('C-DSTAR', 'Koordinator Dinamik Star'),
('C-FELOSE', 'Koordinator FELOSE'),
('C-KJ', 'Koordinator Kompetisi Jaringan'),
('C-LCA', 'Koordinator LCA'),
('C-LCW', 'Koordinator LCW'),
('C-LDG', 'Koordinator LDG'),
('C-OTIK', 'Koordinator OTIK'),
('C-PCA', 'Koordinator PCA'),
('C-RLF', 'Koordinator RLF'),
('C-SEMNAS', 'Koordinator SEMNAS'),
('C-TALKSHOW', 'Koordinator Talkshow'),
('C-WORKSHOP', 'Koordinator Workshop'),
('D-JDG', 'Juri'),
('D-PUB', 'Publik'),
('D-SCH', 'Sekolah'),
('E-SCT', 'Tim Sekolah'),
('X-SUADM', 'Super Administrator');
