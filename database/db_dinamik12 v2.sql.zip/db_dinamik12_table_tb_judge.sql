
-- --------------------------------------------------------

--
-- Table structure for table `tb_judge`
--

DROP TABLE IF EXISTS `tb_judge`;
CREATE TABLE `tb_judge` (
  `judge_id` int(11) NOT NULL,
  `judge_name` varchar(255) NOT NULL,
  `judge_affiliation` varchar(255) NOT NULL,
  `judge_contact` varchar(20) NOT NULL,
  `judge_address` text NOT NULL,
  `judge_cv` varchar(255) NOT NULL,
  `judge_event_id` int(11) NOT NULL,
  `judge_account_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- RELATIONS FOR TABLE `tb_judge`:
--   `judge_event_id`
--       `tb_event` -> `event_id`
--   `judge_account_id`
--       `tb_account` -> `account_id`
--

--
-- Truncate table before insert `tb_judge`
--

TRUNCATE TABLE `tb_judge`;